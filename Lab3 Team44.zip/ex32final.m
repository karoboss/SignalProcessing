%Exercise 2
%%We have 2 orders of the filter
n_order1=2;
n_order2=16;
%%Other variables for the exersice
ts=0.2;
fs=1/0.2;
%%omega_cutoff=2*pi*f_cuttof=>2=2pi*fcuttof=>1/pi
omega_cutoff=2;
frequency_cutoff=1/pi;
%% zone_passband
zone_passband=(1/pi)./(2.5);
ripple_passband=3;
%%Create our frequency domain we want between 0 and 1 so we have to limit
%%[0 1]
start_point=0;
end_point=1;
freq=linspace(start_point,end_point,256);
%%Both our filters highpass
%%Create our highpass digital  with order 2
[upper1,lower1]=cheby1(n_order1,ripple_passband,zone_passband,'high');
filter_order2=freqz(upper1,lower1,256);
%%Create our highpass digital  with order 16
[upper2,lower2]=cheby1(n_order2,ripple_passband,zone_passband,'high');
filter_order16=freqz(upper2,lower2,256);
%%We want the dbs so we need to transform the magnitude into db
filter_order2_db=mag2db(abs(filter_order2));
filter_order16_db=mag2db(abs(filter_order16));
figure;
plot(freq,filter_order2_db);
hold on;
grid on;
plot(freq,filter_order16_db,'r:','Linewidth',2);
hold off;
legend('Order=2', 'Order=16');
xlabel('Frequency Hz');
ylabel('Decibels');
title('Chebyshev  Filters');
%%Exercise 3 part 2
t=0:ts:500*ts;
x_t=1+cos(1.5*t)+cos(5*t);
%%Creating the frequency domain
f=linspace(-fs/2,fs/2-1,500);
%%Make the fft so we have the spectrum
x_t_spectrum=fftshift(fft(x_t, 500));
%%Filter our starting signal
x_t_filter=filter(upper2,lower2,x_t);
%%Make the fft of the filtered so we have the spectrum
x_t_filter_spectrum =fftshift(fft(x_t_filter,500));
%%Start ploting
figure;
subplot(2,2,1);
stem(t,x_t);
xlabel('Seconds');
ylabel('Values');
title('Start signal sampled 500 times');
%%Filter signal
subplot(2,2,2);
stem(t,x_t_filter,'k');
xlabel('Seconds');
ylabel('Values');
title('Filtered signal sampled 500 times');
%%Start signal fft
subplot(2,2,3);
stem(f,x_t_spectrum);
title('spectrumXt');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%Filter signal fft
subplot(2,2,4);
stem(f,x_t_filter_spectrum,'k');
title('spectrumXtFiltered');
xlabel('Frequency Hz');
ylabel('Spectrum Values');


