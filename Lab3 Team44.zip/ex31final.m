%%Excersice 1
%%Here are the frequency 10khz and the ts
fs=10000;
ts=1/10000;
%%Now we create the constants for the ripples we change the second 50 for
%%the second part
ripple_passband=3;
ripple_attenuation=50;
%%Create constants for the passband and stopband zones
%%the zones are multiplied by 2pi so we have omega
zone_passband=2*pi*3000;
zone_stopband=2*pi*4000;
%%We use the command buttord to find the order of the filter and the cutoff freq
[n_order,cutoff_freq] = buttord(zone_passband,zone_stopband,ripple_passband,ripple_attenuation,'s');
display("The order of the filter is "),display(n_order);
display("The cutoff frequency is:"),display(cutoff_freq);
%%We need to use the buttap function to find the poles the zeros and the gain for the
%%transfer func
[zeros,poles,gain] = buttap(n_order);
%%Then we use the zp2tf function to vreate the transfer function from the
%%poles zeros and gain that gives an upper and a lower part
[upper,lower] = zp2tf(zeros,poles,gain);
%%No we make that to a lowpass filter with lp2lp(lowpass analog to lowpass with cutoff)
[upperfinal,lowerfinal] = lp2lp(upper,lower,cutoff_freq);
%%Now we create the analog and the digital filter with the help of the functions
%%freqs and bilinear with freqz
freq=linspace(0,10000/2,2048);
omega_freq=2*pi*freq;
%%Tora theloyme tin apokrisi sixnotitas
analog_filter=freqs(upperfinal,lowerfinal,omega_freq);
%%Transform the s plane analog to z plane digital filter
[digitalupper,digitallower] = bilinear(upperfinal,lowerfinal,10000);
%%digital filter frequency response
digital_filter=freqz(digitalupper,digitallower,freq,10000);
%%We want the dbs so we need to transform the magnitude into db
analogdb=mag2db(abs(analog_filter));
digitaldb=mag2db(abs(digital_filter));
%%Plot the required graph
figure;
plot(freq,analogdb,'r:','Linewidth',2);
hold on;
grid on;
plot(freq,digitaldb);
hold off;
legend('Analog filter', 'Digital filter');
xlabel('Frequency Hz');
ylabel('Decibels');
title('Butterworth  Filters');
%%Exersice 3 first part
%%Makin our time vector with 500 samples and creatin our signal
t=0:ts:500*ts;
x_t=1+cos(1000*t)+cos(16000*t)+cos(30000*t);
%%Creating the frequency domain
f=linspace(-fs/2,fs/2-1,500);
%%Make the fft so we have the spectrum
x_t_spectrum=fftshift(fft(x_t, 500));
%%Filter our starting signal
x_t_filter=filter(digitalupper,digitallower,x_t);
%%Make the fft of the filtered so we have the spectrum
x_t_filter_spectrum =fftshift(fft(x_t_filter,500));
%%Start ploting
figure;
subplot(2,2,1);
stem(t,x_t);
xlabel('Seconds');
ylabel('Values');
title('Start signal sampled 500 times');
%%Filter signal
subplot(2,2,2);
stem(t,x_t_filter,'k');
xlabel('Seconds');
ylabel('Values');
title('Filtered signal sampled 500 times');
%%Start signal fft
subplot(2,2,3);
stem(f,x_t_spectrum);
title('spectrumXt');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%Filter signal fft
subplot(2,2,4);
stem(f,x_t_filter_spectrum,'k');
title('spectrumXtFiltered');
xlabel('Frequency Hz');
ylabel('Spectrum Values');


