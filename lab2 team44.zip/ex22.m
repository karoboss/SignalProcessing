%%First Excersice
%%the sample freq is 1hz and the ts
fs=1;
ts=1;
%%We need to use the transfer function for the nominator and the denominator
%%g1 G1(z)=0.2*z/z-0.9.
%%We need the same amount of nymbers or else it doesnt show the roots good on circle
%%The first is for z
upperg1=[0.2 0];
lowerg1=[1 -0.9];
%%g2=1/z+0.2
upperg2=[0 1];
lowerg2=[1 0.2];
%%The tf functions on the frequency domain 1Hz
g1=tf(upperg1,lowerg1,1);
g2=tf(upperg2,lowerg2,1);
%%the needed multiplications to create the total function
hz=g1*g2;
%%We need to display the results
display("The g1 function is"),display(g1);
display("The g2 function is"),display(g2);
display("The transfer function is"),display(hz);
%%b
%%create both the upper part and the lower like before
upperhz=[0 0.2 0];
lowerhz=[1 -0.7 -0.18];
%%calculating the poles and roots so to display them then
zeros=roots(upperhz);
poles=roots(lowerhz);
%%Plotting our diagram
figure;
zplane(upperhz,lowerhz);
xlabel("Real");
ylabel("Imagine");
title("The diagram of poles and zeros");
%%Displaying our poles and zeros in the command
display("The poles of the transfer function is"),display(poles);
display("The zeros of the transfer function is"),display(zeros);
%%creating the correct frequency space 128 parts
frequ=linspace(-pi,pi,128);
figure;
%%With frequency domain
freqz(upperhz,lowerhz,frequ);
figure;
%%Without frequency domain
freqz(upperhz,lowerhz);
title("The diagram without frequency");
%%Adding the pole we chance the denominator
lowerhz2=[1 -1.7 0.52 0.18];
figure;
freqz(upperhz,lowerhz2,frequ);

