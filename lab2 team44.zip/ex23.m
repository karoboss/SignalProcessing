%%2 exersice
%%Create the upper and lower like the excersixe before
upper=[4 -3.5 0];
lower=[1 -2.5 1];
%%use of residuez function as asked
[ro,po,ko]=residuez(upper,lower);
%%start the symbolic
syms s;
%%Create the nominators and the denominators for the g1 g2
upperg1=ro(1);
lowerg1=1-po(1)*s^(-1);
upperg2=ro(2);
lowerg2=1-po(2)*s^(-1);
%%Create our g1 and g2
g1=upperg1./lowerg1;
g2=upperg2./lowerg2;
%%Adding them together to create final h
h=g1+g2;
pretty(h)
%reverse iztrans in octave we cant do iztrans so i did on matlab
%%The reverse function
Hrever=iztrans(h)
