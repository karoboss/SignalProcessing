%%random times of our randoms signals
time_ta=[-5:1:5];
time_tb=[-15:1:15];
%%random values of each signal dependent to the length of the time vectors
a=[2,6,-4,12,-16,17,14,0,3,-19,20];
b=[2,5,14,13,18,17,-12,3,12,0,1,16,18,13,4,6,7,9,6,-13,20,2,-6,15,16,-12,9,-8,19,14,5];
%%Plotting the signals a and b both in the same plot
%%signal a color cyan signal b colour red
figure;
stem(time_ta,a,"c");
hold on;
stem(time_tb,b,"r");
title('Both random signals');
xlabel('Seconds');
ylabel('Values');
hold off;
%%Reversing the signal b and plotting it again like before with signal a
%%signal a colour cyan, signal b colour red
%%to anestrammeno diasthma oysiastika ksekinaei apo to teleos toy kanomnikoy
%%me vhma -1 mexri to proto stoixeio toy
b_2=b(end:-1:1);
figure;
stem(time_tb,b_2,"r");
hold on;
stem(time_ta,a,"c");
title('Both random signals but the second is reflected');
xlabel('Seconds');
ylabel('Values');
hold off;
%%About the convolution...
tconv = [min(time_ta)+min(time_tb):1:max(time_ta)+max(time_tb)];
%%Padding helping variables for a and b seperately
padding_for_astart=min(time_ta)-min(tconv);
padding_for_aend=max(tconv)-max(time_ta);
%%For b
padding_for_bstart=min(time_tb)-min(tconv);
padding_for_bend=max(tconv)-max(time_tb);
%Zero padding signals A, B and B_reflected.
a_padded=[zeros(1,padding_for_astart) a zeros(1,padding_for_aend)];
b_padded_reverse = [zeros(1,padding_for_bstart) b_2 zeros(1,padding_for_bend)];
%%For loop to create the sum for the length 20+20=40 without using func conv
for i=1:41
    unusualconv(i) = sum(a_padded.*(circshift(b_padded_reverse,i-tconv(1))));
endfor
%%Plotting both convolutions to see if they match
figure;
stem(tconv, unusualconv);
legend('Unusual conv');
title('Unusual convolutions');
xlabel('Seconds');
ylabel('Values');
figure;
stem(tconv, conv(a,b),"g");
legend('Function conv');
title('Function convolutions');
xlabel('Seconds');
ylabel('Values');
%%apla sto ena exoyme tin klassiki senyliksi kai sto allo prosoxi pollaplasiazoyme
%% ta padded signal allios vgazei error diaforetiko megethoys ston pollaplasiasmo

%%apodeiksi toy deuteroy meroys ths protis askisis
%%For start i create like before 2 discrete signals and i conv them
%%then i use fft with the length of conv so we have same matrixes and multiply
%%them and use ifft to reverse so we have the same diagramms which is what
%%we want
time_ta_test=[-2:1:2];
time_tb_test=[-2:1:2];
a_test=[2,1,3,4,5];
b_test=[5,7,5,2,1];
%%time for conv
tconv_test=[-4:1:4];
test_conv=conv(a_test,b_test);
figure;
subplot(4,1,1);
stem(time_ta_test,a_test);
title('ATEST');
xlabel('Seconds');
ylabel('Values');
subplot(4,1,2);
stem(time_tb_test,b_test);
title('BTEST');
xlabel('Seconds');
ylabel('Values');
subplot(4,1,3);
stem(tconv_test,test_conv);
title('CONVTEST');
xlabel('Seconds');
ylabel('Values');
%%second part using fourier
fourier_a=fft(a_test,length(test_conv));
fourier_b=fft(b_test,length(test_conv));
fourier_final=(ifft(fourier_a.*fourier_b));
subplot(4,1,4);
stem(tconv_test,fourier_final);
title('CONV AYTHENTICATION');
xlabel('Seconds');
ylabel('Values');




