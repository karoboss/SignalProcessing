%%fmax=40hz So from criteria nyquist we need to have fs>=2*40=80
%%so we choose nf at least 80 so we choose 256
nf=256;
ts=1/256;
fs=1/ts;
%%we need to have 128 samples so 1/256*128 is our final time so we dont have aliasing 0.5s
%%our usual step
step=0.001;
t_xt=0:step:0.5;
xt=10*cos(2*pi*20*t_xt)-4*sin(2*pi*40*t_xt+5);
figure;
stem(t_xt,xt,'r');
title('Our signal with Fs=256Hz with no aliasing');
xlabel('Seconds');
ylabel('Values');
%%For the spectrum
freq=linspace(-fs/2,fs/2-1,fs);
spectrum_xt=fftshift(abs(fft(xt,nf)*ts));
figure;
stem(freq,spectrum_xt,'r','LineWidth',1);
title('Our spectrumXt');
xlabel('Frequency Hz');
ylabel('Spectrum Values');


