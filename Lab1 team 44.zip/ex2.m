%%First of all we have to create our signal
%%We use very small step so we can monitor best
step=0.001;
t_xt=0:step:0.5;
xt=5*cos(24*pi*t_xt)-2*sin(1.5*pi*t_xt);
%%Plotting the signal
figure;
plot(t_xt,xt);
xlabel('Seconds');
ylabel('Values');
title('The starting signal');
%%Continue to create the sampling
%%Ts=1/48
t_xt_sample1=0:(1/48):0.5;
xt_sample1=5*cos(24*pi*t_xt_sample1)-2*sin(1.5*pi*t_xt_sample1);
figure;
plot(t_xt,xt);
hold on;
stem(t_xt_sample1,xt_sample1);
title("Sampling 1/48s");
%%1/24
t_xt_sample2=0:(1/24):0.5;
xt_sample2=5*cos(24*pi*t_xt_sample2)-2*sin(1.5*pi*t_xt_sample2);
figure;
plot(t_xt,xt);
hold on;
stem(t_xt_sample2,xt_sample2);
title("Sampling 1/24s");
%%1/12
t_xt_sample3=0:(1/12):0.5;
xt_sample3=5*cos(24*pi*t_xt_sample3)-2*sin(1.5*pi*t_xt_sample3);
figure;
plot(t_xt,xt);
hold on;
stem(t_xt_sample3,xt_sample3);
title("Sampling 1/12s");
%%1/44
t_xt_sample4=0:(1/44):0.5;
xt_sample4=5*cos(24*pi*t_xt_sample4)-2*sin(1.5*pi*t_xt_sample4);
figure;
plot(t_xt,xt);
hold on;
stem(t_xt_sample4,xt_sample4);
title("Sampling 1/44s");

