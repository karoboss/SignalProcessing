%%8000hz sample frequency
fs=8000;
ts=1/fs;
%%we are checking in 40 periods for all the different signals so we can have
%%same axis
n = 0:0.4*fs;
%%for each frequency we create new signal and we stem it to the same
%%frequency vector we create from linespace like the exercise before
%%For freq 100hz
xt=sin(2*pi*(100/8000)*n+44);
freq=linspace(-fs/2,fs/2-1,fs);
spectrum_xt=fftshift(abs(fft(xt,fs)*ts));
figure;
subplot(4,2,1);
stem(freq,spectrum_xt);
title('100HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%for freq 225Hz
xt2 = sin(2*pi*(225/8000)*n+44);
spectrum_xt2=fftshift(abs(fft(xt2,fs)*ts));
subplot(4,2,2);
stem(freq,spectrum_xt2);
title('225HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%For freq 350hz
xt3 = sin(2*pi*(350/8000)*n+44);
spectrum_xt3=fftshift(abs(fft(xt3,fs)*ts));
subplot(4,2,3);
stem(freq,spectrum_xt3);
title('350HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%For freq475hz
xt4 = sin(2*pi*(475/8000)*n+44);
spectrum_xt4=fftshift(abs(fft(xt4,fs)*ts));
subplot(4,2,4);
stem(freq,spectrum_xt4);
title('475HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%For freq 7525 hz
xt5 = sin(2*pi*(7525/8000)*n+44);
spectrum_xt5=fftshift(abs(fft(xt5,fs)*ts));
figure;
subplot(4,2,1);
stem(freq,spectrum_xt5);
title('7525HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%For freq 7650 hz
xt6 = sin(2*pi*(7650/8000)*n+44);
spectrum_xt6=fftshift(abs(fft(xt6,fs)*ts));
subplot(4,2,2);
stem(freq,spectrum_xt6);
title('7650HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%For freq 7775 hz
xt7 = sin(2*pi*(7775/8000)*n+44);
spectrum_xt7=fftshift(abs(fft(xt7,fs)*ts));
subplot(4,2,3);
stem(freq,spectrum_xt7);
title('7775HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
%%For freq 7900 hz
xt8 = sin(2*pi*(7900/8000)*n+44);
spectrum_xt8=fftshift(abs(fft(xt8,fs)*ts));
subplot(4,2,4);
stem(freq,spectrum_xt8);
title('7900HZ');
xlabel('Frequency Hz');
ylabel('Spectrum Values');


