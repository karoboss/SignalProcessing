%%We put the package from our signal so we dont have to load
%%it every time i use it
pkg load signal;
%Askhsh1
%%Variables of the exersice
omega_cuttof=0.4*pi;
frequency_cuttoff=(omega_cuttof)/(2*pi);
fs=100;
ts=1/100;
%%Normalized frequency cuttof
omega_normalized=frequency_cuttoff/(fs/2); %%0.004
%%order
n=21;
%%firl used to create n order lowpass filter either rectangular or hamming window
rectangular_window= fir1(n-1, omega_normalized, 'low', 'rectwin');
hamming_window = fir1(n-1, omega_normalized, 'low', 'hamming');
%%Using freqz we can now calculate the windows frequency response
[H_rect Angular_rect] = freqz(rectangular_window, n);
[H_ham Angular_ham] = freqz(hamming_window, n);
%%We need the abs values for our diagrams
H_rect_abs=abs(H_rect);
H_ham_abs=abs(H_ham);
%%Start plooting we can also use any frequency diagra size 1x512
figure;
plot(Angular_rect,H_rect_abs,'k');
hold on;
plot(Angular_rect,H_ham_abs,'g');
legend('Rectangular ', 'Hamming');
xlabel('omegaNormalized frequency');
ylabel('Frequency response Magnitude');
title('Frequency Response for Both Windows')

