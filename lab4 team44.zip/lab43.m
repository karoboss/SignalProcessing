%%We put the package from our signal so we dont have to load
%%it every time i use it
pkg load signal;
%Askhsh2 like previous exersice
%%Variables of the exersice
omega_cuttof=0.5*pi;
frequency_cuttoff=(omega_cuttof)/(2*pi);
fs=50;
ts=1/50;
denominator=1;
%%Normalized frequency cuttof
omega_normalized=frequency_cuttoff/(fs/2); %%0.005
%%orders
n1=21;
n2=41;
%%firl used to create n order lowpass filter either rectangular or hamming window
hamming_window1= fir1(n1-1, omega_normalized, 'low', 'hamming');
hamming_window2 = fir1(n2-1, omega_normalized, 'low', 'hamming');
hanning_window1= fir1(n1-1, omega_normalized, 'low', 'hanning');
hanning_window2 = fir1(n2-1, omega_normalized, 'low', 'hanning');
%%Using freqz we can now calculate the windows frequency response
[H_ham1 Angular_ham1] = freqz(hamming_window1, n1);
[H_ham2 Angular_ham2] = freqz(hamming_window2, n2);
[H_han1 Angular_han1] = freqz(hanning_window1, n1);
[H_han2 Angular_han2] = freqz(hanning_window2, n2);
%%We need the abs values for our diagrams
H_ham1_abs=abs(H_ham1);
H_ham2_abs=abs(H_ham2);
H_han1_abs=abs(H_han1);
H_han2_abs=abs(H_han2);
%%Start plotting like previous exersice
figure;
subplot(2,2,1);
plot(Angular_ham1,H_ham1_abs,'k');
xlabel('omegaNormalized frequency');
ylabel('Frequency response Magnitude');
title('Frequency Response for Hamming 21');
legend('n=21');
subplot(2,2,2);
plot(Angular_ham2,H_ham2_abs,'g');
xlabel('omegaNormalized frequency');
ylabel('Frequency response Magnitude');
title('Frequency Response for Hamming 41');
legend('n=41');
subplot(2,2,3);
plot(Angular_han1,H_han1_abs,'b');
xlabel('omegaNormalized frequency');
ylabel('Frequency response Magnitude');
title('Frequency Response for Hanning 21');
legend('n=21');
subplot(2,2,4);
plot(Angular_han2,H_han2_abs,'r');
xlabel('omegaNormalized frequency');
ylabel('Frequency response Magnitude');
title('Frequency Response for Hanning 41');
legend('n=41');
%%Now like the previous exersice lab3
%%signal from exersice
t=0:ts:500*ts;
f=linspace(-fs/2,fs/2-1,501);
x_t=sin(15*t)+0.25*sin(200*t);
x_t_spectrum=fftshift(fft(x_t));
x_t_filter1=filter(hamming_window1,denominator,x_t);
x_t_filter2=filter(hamming_window2,denominator,x_t);
x_t_filter3=filter(hanning_window1,denominator,x_t);
x_t_filter4=filter(hanning_window2,denominator,x_t);
x_t_filter_spectrum1 =fftshift(fft(x_t_filter1));
x_t_filter_spectrum2 =fftshift(fft(x_t_filter2));
x_t_filter_spectrum3 =fftshift(fft(x_t_filter3));
x_t_filter_spectrum4 =fftshift(fft(x_t_filter4));
figure;
plot(f,abs(x_t_spectrum));
title('spectrumXt');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
figure;
%%Filter signal fft
subplot(2,2,1);
plot(f,abs(x_t_filter_spectrum1),'k');
title('spectrumXtFiltered Hamming n=21');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
subplot(2,2,2);
plot(f,abs(x_t_filter_spectrum2),'g');
title('spectrumXtFiltered Hamming n=41');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
subplot(2,2,3);
plot(f,abs(x_t_filter_spectrum3),'k');
title('spectrumXtFiltered Hanning n=21');
xlabel('Frequency Hz');
ylabel('Spectrum Values');
subplot(2,2,4);
plot(f,abs(x_t_filter_spectrum4),'g');
title('spectrumXtFiltered Hamming n=41');
xlabel('Frequency Hz');
ylabel('Spectrum Values');








